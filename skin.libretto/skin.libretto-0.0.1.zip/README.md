# skin.libretto

Minimal scaffold of the Libretto Kodi skin (Kodi 21 Omega).  
Use this as a base and iterate.

- Resolution: 1080i
- GUI API: xbmc.gui 5.17.0